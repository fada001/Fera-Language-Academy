import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';

const root = new URL('../', import.meta.url);
const source = new URL('source/', root);
const assets = new URL('assets/', source);
const output = new URL('public/index.html', root);
const configPath = new URL('vercel.json', root);
const assetTypes = { png: 'image/png', svg: 'image/svg+xml', woff2: 'font/woff2' };
const readText = url => readFileSync(url, 'utf8').replace(/\r\n?/g, '\n');

function embedAsset(path) {
  const type = assetTypes[path.split('.').at(-1)];
  if (!type) throw new Error('Unsupported embedded asset: ' + path);
  return 'data:' + type + ';base64,' + readFileSync(new URL(path, assets)).toString('base64');
}

function cspHash(text) {
  return "'sha256-" + createHash('sha256').update(text, 'utf8').digest('base64') + "'";
}

const css = '\n' + readText(new URL('site.css', assets)).replace(
  /url\(["']?\.\/([^"')]+)["']?\)/g,
  (_, path) => 'url("' + embedAsset(path) + '")'
);
const fields = readText(new URL('form-fields.js', assets)).replace(/^export /gm, '');
const app = readText(new URL('site.js', assets)).replace(/^import [^\n]+\n/, '');
const script = '\n(() => {\n' + fields + app + '})();\n';

if (/<\/style\b/i.test(css) || /<\/script\b/i.test(script)) {
  throw new Error('An embedded asset would close its HTML tag.');
}

const page = readText(new URL('index.html', source))
  .replace(/\b(href|src)="\/assets\/([^"]+\.(?:png|svg))"/g,
    (_, attribute, path) => attribute + '="' + embedAsset(path) + '"')
  .replace('<link rel="stylesheet" href="/assets/site.css">', () => '<style>' + css + '</style>')
  .replace('<script type="module" src="/assets/site.js"></script>\n', '')
  .replace('</body>', () => '<script>' + script + '</script>\n</body>');

const config = JSON.parse(readText(configPath));
const csp = config.headers[0].headers.find(header => header.key === 'Content-Security-Policy');
csp.value = [
  "default-src 'none'", "base-uri 'none'", "frame-ancestors 'none'", "form-action 'self'",
  'script-src ' + cspHash(script), 'style-src ' + cspHash(css), "img-src 'self' data:",
  'font-src data:', "connect-src 'self'", "object-src 'none'"
].join('; ');

writeFileSync(output, page);
writeFileSync(configPath, JSON.stringify(config, null, 2) + '\n');
