import nodemailer from 'nodemailer';

const recipient = 'ferasupport1@gmail.com';
const deliveries = new Map();
const receiptLifetime = 2 * 60 * 60 * 1000;

const labels = {
  firstName: 'First name', lastName: 'Last name', email: 'Email', phone: 'Phone',
  telegram: 'Telegram', country: 'Country', city: 'City', ageGroup: 'Age group',
  goal: 'Main goal', program: 'Program', previous: 'Previous English study',
  time: 'Preferred class time', referral: 'How they heard about us',
  language: 'Website language', message: 'Message'
};

export function gmailTransport() {
  const sender = (process.env.GMAIL_USER || recipient).trim();
  const pass = (process.env.GMAIL_APP_PASSWORD || '').replace(/\s/g, '');
  if (!/^[a-z0-9._+%-]+@gmail\.com$/i.test(sender) || !/^[a-z]{16}$/i.test(pass)) {
    return null;
  }

  const transport = nodemailer.createTransport({
    host: 'smtp.gmail.com',
    port: 465,
    secure: true,
    auth: { user: sender, pass },
    tls: { minVersion: 'TLSv1.2' },
    connectionTimeout: 6_000,
    greetingTimeout: 5_000,
    socketTimeout: 8_000,
    dnsTimeout: 4_000,
    disableFileAccess: true,
    disableUrlAccess: true
  });
  return { sender, transport };
}

function formatMail(app, ref, result, answerSummary) {
  const lines = ['Reference: ' + ref];
  if (result) {
    lines.push(
      'Estimated CEFR level: ' + result.level,
      'Score: ' + result.correct + '/' + result.total +
        ' (' + Math.round(result.correct / result.total * 100) + '%)',
      'Time used: ' + Math.floor(result.elapsed / 60) + ':' +
        String(result.elapsed % 60).padStart(2, '0'),
      'Scores by level: ' + Object.entries(result.per).map(([level, score]) =>
        level + ' ' + score.c + '/' + score.n
      ).join(' | '),
      'Question results (✓ correct, ✗ incorrect, – unanswered): ' + answerSummary
    );
  }
  lines.push('', 'Student application');
  for (const [key, label] of Object.entries(labels)) {
    lines.push(label + ': ' + (app[key] || '—').replace(/\n/g, '\n  '));
  }
  return lines.join('\n');
}

export async function deliverOnce(gmail, { id, fingerprint, app, ref, result, answerSummary }) {
  const now = Date.now();
  for (const [key, entry] of deliveries) {
    if (entry.expires <= now) deliveries.delete(key);
  }

  const existing = deliveries.get(id);
  if (existing) {
    return existing.fingerprint === fingerprint ? existing.delivery : { state: 'conflict' };
  }
  if (deliveries.size >= 5000) return { state: 'failed', result };

  const delivery = send(gmail, { id, app, ref, result, answerSummary })
    .then(state => ({ state, result }));
  deliveries.set(id, { fingerprint, delivery, expires: now + receiptLifetime });
  const outcome = await delivery;
  if (outcome.state !== 'sent') deliveries.delete(id);
  return outcome;
}

async function send({ sender, transport }, { id, app, ref, result, answerSummary }) {
  try {
    const info = await transport.sendMail({
      from: { name: 'Fera Language Academy', address: sender },
      to: { address: recipient },
      replyTo: { address: app.email },
      envelope: { from: sender, to: [recipient] },
      subject: (result ? 'Placement result ' : 'New application ') + ref,
      text: formatMail(app, ref, result, answerSummary),
      messageId: '<' + id + '@gmail.com>'
    });
    return info.accepted.includes(recipient) ? 'sent' : 'failed';
  } catch (error) {
    const code = typeof error.code === 'string' && /^[A-Z0-9]+$/.test(error.code)
      ? error.code : 'UNKNOWN';
    console.error('Placement email failed:', code);
    return 'failed';
  }
}
