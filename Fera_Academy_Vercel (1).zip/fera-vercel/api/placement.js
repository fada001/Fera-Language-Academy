import { createHmac, randomUUID, timingSafeEqual } from 'node:crypto';
import { FIELDS, validateField } from '../source/assets/form-fields.js';
import { questions } from '../server/question-bank.js';
import { deliverOnce, gmailTransport } from '../server/mail.js';

const fields = Object.values(FIELDS).flat();
const publicQuestions = questions.map(({ q, o }) => ({ q, o }));
const levels = [...new Set(questions.map(({ l }) => l))];
const testSeconds = 25 * 60;
const submitGrace = 2 * 60 * 1000;
const sessionLifetime = 2 * 60 * 60 * 1000;
const maxBody = 12 * 1024;
const sessionSecret = process.env.PLACEMENT_SECRET || '';
const key = /^[a-f0-9]{64}$/i.test(sessionSecret) ? Buffer.from(sessionSecret, 'hex') : null;
const questionVersion = key ? digest('questions', questions) : '';

function json(status, body, extraHeaders) {
  return Response.json(body, {
    status,
    headers: { 'Cache-Control': 'no-store', ...extraHeaders }
  });
}

function digest(purpose, value) {
  return createHmac('sha256', key).update(purpose + '\0' + JSON.stringify(value)).digest('hex');
}

function seal(payload) {
  const encoded = Buffer.from(JSON.stringify(payload)).toString('base64url');
  return encoded + '.' + digest('session', encoded);
}

function readToken(token, kind, now) {
  if (typeof token !== 'string' || token.length > 1500) return null;
  const match = /^([\w-]+)\.([a-f0-9]{64})$/.exec(token);
  if (!match) return null;
  const [, encoded, signature] = match;
  if (!timingSafeEqual(Buffer.from(signature, 'hex'), Buffer.from(digest('session', encoded), 'hex'))) {
    return null;
  }
  const claims = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8'));
  return claims.kind === kind && claims.expires > now ? claims : null;
}

function readApplication(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) return null;
  const app = {};
  for (const field of fields) {
    const { value, key: error } = validateField(field, input[field.k]);
    if (error) return null;
    app[field.k] = value;
  }
  if (!['English', 'Dari'].includes(input.language)) return null;
  app.language = input.language;
  return app;
}

function score(answers, elapsed) {
  const per = Object.fromEntries(levels.map(level => [level, { c: 0, n: 0 }]));
  let correct = 0;
  questions.forEach((question, index) => {
    const group = per[question.l];
    group.n++;
    if (answers[index] === question.a) {
      group.c++;
      correct++;
    }
  });
  let level = levels[0];
  for (const candidate of levels) {
    if (per[candidate].c / per[candidate].n < 0.6) break;
    level = candidate;
  }
  return { level, correct, total: questions.length, per, elapsed };
}

async function readJson(request) {
  if (Number(request.headers.get('content-length')) > maxBody) return { status: 413 };
  if (!request.body) return { status: 400 };

  const reader = request.body.getReader();
  const chunks = [];
  let size = 0;
  try {
    for (let chunk = await reader.read(); !chunk.done; chunk = await reader.read()) {
      size += chunk.value.byteLength;
      if (size > maxBody) {
        reader.cancel().catch(() => {});
        return { status: 413 };
      }
      chunks.push(chunk.value);
    }
    const data = JSON.parse(Buffer.concat(chunks).toString('utf8'));
    return data && typeof data === 'object' && !Array.isArray(data) ? { data } : { status: 400 };
  } catch {
    return { status: 400 };
  } finally {
    reader.releaseLock();
  }
}

async function register(data, now) {
  const app = readApplication(data.app);
  if (!app || data.consent !== true || data.honeypot !== '' ||
      typeof data.registrationId !== 'string' ||
      !/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i.test(data.registrationId)) {
    return json(400, { error: 'invalid' });
  }
  const gmail = gmailTransport();
  if (!gmail) return json(503, { error: 'unavailable' });

  const appHash = digest('application', app);
  const ref = 'FERA-' + digest('reference', [data.registrationId, appHash]).slice(0, 16).toUpperCase();
  const { state } = await deliverOnce(gmail, {
    id: 'fera-registration-' + ref, fingerprint: appHash, app, ref
  });
  return json(200, {
    ref,
    registration: seal({ kind: 'registration', ref, appHash, expires: now + sessionLifetime }),
    emailSent: state === 'sent'
  });
}

function start(data, now) {
  const registration = readToken(data.registration, 'registration', now);
  if (!registration) return json(410, { error: 'registrationExpired' });
  const { ref, appHash } = registration;
  const attempt = seal({
    kind: 'attempt', ref, appHash, id: randomUUID(), started: now,
    expires: now + testSeconds * 1000 + submitGrace + sessionLifetime,
    questionVersion
  });
  return json(200, { attempt, questions: publicQuestions, duration: testSeconds });
}

async function finish(data, now) {
  const attempt = readToken(data.attempt, 'attempt', now);
  if (!attempt || attempt.questionVersion !== questionVersion) return json(410, { error: 'attemptExpired' });

  const { app, answers } = data;
  const applicant = readApplication(app);
  if (!applicant || digest('application', applicant) !== attempt.appHash ||
      !Array.isArray(answers) || answers.length !== questions.length ||
      !answers.every(answer => answer === null || (Number.isInteger(answer) && answer >= 0 && answer < 4))) {
    return json(400, { error: 'invalid' });
  }

  const fingerprint = digest('answers', answers);
  const previous = readToken(data.retry, 'retry', now);
  let elapsed;
  if (previous && previous.attemptId === attempt.id && previous.fingerprint === fingerprint) {
    elapsed = previous.elapsed;
  } else {
    const timeSpent = now - attempt.started;
    if (timeSpent > testSeconds * 1000 + submitGrace) return json(410, { error: 'attemptExpired' });
    elapsed = Math.min(testSeconds, Math.max(0, Math.round(timeSpent / 1000)));
  }

  const result = score(answers, elapsed);
  const answerSummary = questions.map(({ a }, index) => {
    const answer = answers[index];
    return (index + 1) + (answer === null ? '–' : answer === a ? '✓' : '✗');
  }).join(' ');
  const gmail = gmailTransport();
  const delivery = gmail ? await deliverOnce(gmail, {
    id: 'fera-result-' + attempt.id, fingerprint, app: applicant, ref: attempt.ref, result, answerSummary
  }) : { state: 'failed', result };
  if (delivery.state === 'conflict') return json(409, { error: 'conflict' });
  return json(200, {
    result: delivery.result,
    emailSent: delivery.state === 'sent',
    retry: delivery.state === 'sent' ? null : seal({
      kind: 'retry', attemptId: attempt.id, fingerprint, elapsed,
      expires: Math.min(now + sessionLifetime, attempt.expires)
    })
  });
}

export default {
  async fetch(request) {
    if (request.method !== 'POST') return json(405, { error: 'method' }, { Allow: 'POST' });
    const origin = request.headers.get('origin');
    const fetchSite = request.headers.get('sec-fetch-site');
    if (origin !== new URL(request.url).origin || (fetchSite && fetchSite !== 'same-origin')) {
      return json(403, { error: 'origin' });
    }
    if (request.headers.get('content-type')?.split(';')[0].trim().toLowerCase() !== 'application/json') {
      return json(415, { error: 'type' });
    }
    if (!key) return json(503, { error: 'unavailable' });

    const { status, data } = await readJson(request);
    if (!data) return json(status, { error: 'invalid' });
    const now = Date.now();
    try {
      if (data.action === 'register') return await register(data, now);
      if (data.action === 'start') return start(data, now);
      if (data.action === 'finish') return await finish(data, now);
      return json(400, { error: 'invalid' });
    } catch {
      console.error('Placement request failed.');
      return json(503, { error: 'unavailable' });
    }
  }
};
