# Fera Language Academy

Your English and Dari academy website, student application and 30-question placement test. The test runs for 25 minutes. Vercel grades the answers and Gmail sends the registration and result emails to **ferasupport1@gmail.com**. Both messages share a reference number. The result email includes the student's details, estimated CEFR level, score, time used and score by level.

## Open the HTML on your computer

Double-click `public/index.html` to preview the website in your browser. The page contains its own styles, scripts, logos and fonts. Use your deployed site for live registration, scoring and email delivery.

## 1. Deploy the project

Unzip the archive and use the whole **fera-vercel** folder as the Vercel project root. It contains `public/`, `api/`, `server/`, `package.json` and `vercel.json`.

You can import a private Git repository containing that folder's contents in the [Vercel dashboard](https://vercel.com/dashboard). Use the **Other** framework preset. The configuration already sets `public` as the output directory and deploys the function in `api/`.

To deploy directly from your computer, open a terminal in the extracted **fera-vercel** folder and run:

```sh
npx vercel@latest login
npx vercel@latest link
```

Choose or create the Vercel project when prompted. After adding the environment variables below, run `npx vercel@latest deploy --prod` from the same folder. Vercel assigns a `.vercel.app` address automatically. A custom domain is optional.

Vercel's free Hobby plan is for personal, non-commercial use. If the site enrolls students in paid classes, use a Vercel plan that permits commercial use. See [Vercel Hobby plan](https://vercel.com/docs/plans/hobby).

## 2. Connect Gmail

1. Enable 2-Step Verification for the personal Gmail account that will send the emails. Create a dedicated [Google App Password](https://myaccount.google.com/apppasswords) for this project. The simplest setup uses `ferasupport1@gmail.com` as the sender and recipient. You can use a different personal Gmail account as the sender if preferred. See [Google's App Password guide](https://support.google.com/mail/answer/185833).
2. In the Vercel project, open **Settings → Environment Variables**. Add the following to **Production**. Enable the sensitive option for the password and signing secret when offered.

| Variable | Value |
| --- | --- |
| `GMAIL_USER` | The Gmail address that generated the App Password. Defaults to `ferasupport1@gmail.com`. |
| `GMAIL_APP_PASSWORD` | The dedicated 16-character Google App Password. |
| `PLACEMENT_SECRET` | A random 64-character hexadecimal string. Run the command below once to generate it. |

```sh
node -p "require('node:crypto').randomBytes(32).toString('hex')"
```

Enter the secret values directly in Vercel. Keep them out of your repository, website files, and chat. A new deployment is required for environment variable changes to take effect. Use the **Redeploy** action if the dashboard already created an initial deployment.

## 3. Limit spam before sharing the website

In Vercel, go to **Firewall → Configure → New Rule**. Match requests with **Method = POST** and **Request Path starts with /api/**. Choose **Rate Limit**, a **10 minute** fixed window, key **IP**, limit **60**, and response **429**. Save and publish the rule. If students share a school network, adjust the limit to suit the number taking the test together. See the [Vercel rate-limiting guide](https://vercel.com/docs/vercel-firewall/vercel-waf/rate-limiting).

## 4. Verify delivery

1. Open the production `.vercel.app` address in a private browser window. Use sample details and a recognizable name, then submit the registration and take the test.
2. Check **ferasupport1@gmail.com** for **New application FERA-…** and **Placement result FERA-…**. The reference must match in both emails and on the website. Check Spam and All Mail if the messages are missing.
3. If a message fails, the student sees a delivery status and can retry the result email while the page is open. The result email includes all registration details, so it can recover a failed registration email. If Gmail blocks SMTP or revokes the App Password, check your Google account and the Vercel function logs, update the password if needed, redeploy, and run another sample submission. See the [Gmail SMTP troubleshooting guide](https://nodemailer.com/guides/using-gmail).

Live Gmail delivery depends on your account configuration and Google's sending limits. The app awaits Gmail's SMTP acceptance before reporting success. There is no saved submission queue. A retry after a lost response can produce a duplicate if Vercel handles it on another instance. Use the reference to match related messages.

## Edit your website

- **Page content** — `source/index.html`.
- **Colors and layout** — `source/assets/site.css`.
- **Dari translations and social links** — `source/assets/site.js`. Set the optional Telegram handles or HTTPS links near the top.
- **Form fields and options** — `source/assets/form-fields.js`.
- **Questions and answer key** — `server/question-bank.js`. Keep this file outside `public/`. The README and website text assume 30 questions, with four choices per question.
- **Email formatting and recipient** — `server/mail.js`. The current recipient is fixed to `ferasupport1@gmail.com`. Students cannot change it through the form.

After editing these website files, run `npm run build:html` to regenerate `public/index.html` and its matching security headers in `vercel.json`. Deploy both generated files together.

The project serves its fonts, logos and scripts locally. Student details stay in the open page until needed for registration or final submission. The site sends them to your Vercel function and Gmail and does not write them to browser storage or an application database.
