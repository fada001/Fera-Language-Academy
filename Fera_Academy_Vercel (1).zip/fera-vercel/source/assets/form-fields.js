export const FIELDS = {
personal: [
 {k:'firstName',en:'First name',type:'text',req:1,ac:'given-name',ph:'e.g. Ahmad'},
 {k:'lastName',en:'Last name',type:'text',req:1,ac:'family-name',ph:'e.g. Ahmadi'},
 {k:'country',en:'Country',type:'text',req:1,ac:'country-name',list:'countries',ph:'Start typing…'},
 {k:'city',en:'City',type:'text',req:1,ac:'address-level2',ph:'e.g. Herat'},
 {k:'ageGroup',en:'Age group',type:'select',req:1,full:1,opts:['Under 15','15–17','18–24','25–34','35 or older']}
],
contact: [
 {k:'email',en:'Email address',type:'email',req:1,ac:'email',ltr:1,ph:'name@example.com'},
 {k:'phone',en:'Phone number',type:'tel',req:1,ac:'tel',ltr:1,ph:'+93 700 000 000',hint:'Include your country code.'},
 {k:'telegram',en:'Telegram number or username',type:'text',req:1,ltr:1,ph:'@username or +93…',hint:'We will add you to your class group with this.',full:1}
],
learning: [
 {k:'goal',en:'Your main goal',type:'select',req:1,opts:['Work and career','Study abroad or scholarship','IELTS / TOEFL exam','Travel or living abroad','Everyday conversation','Other']},
 {k:'program',en:'Program of interest',type:'select',req:1,opts:['General English','Spoken English','IELTS & TOEFL','Business English','Private 1-on-1','Not sure yet']},
 {k:'previous',en:'Previous English study',type:'select',req:1,opts:['Never studied English','Less than 1 year','1–3 years','More than 3 years']},
 {k:'time',en:'Preferred class time',type:'select',req:1,opts:['Morning','Afternoon','Evening','Weekends','Any time']},
 {k:'referral',en:'How did you hear about us?',type:'select',opts:['Telegram','Instagram','Facebook','Friend or family','Other']},
 {k:'message',en:'Message (optional)',type:'textarea',full:1,ph:'Anything you would like us to know'}
]};

const phone = value => /^\+?[0-9 ()-]{7,20}$/.test(value) && value.replace(/\D/g, '').length >= 7;
const email = /^[A-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[A-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@[A-Z0-9](?:[A-Z0-9-]*[A-Z0-9])?(?:\.[A-Z0-9](?:[A-Z0-9-]*[A-Z0-9])?)+$/i;
const telegramName = '[A-Za-z][A-Za-z0-9_]{4,31}';
const telegram = new RegExp('^(?:@?|https?://t\\.me/)' + telegramName + '/?$', 'i');

export function validateField(field, input) {
  if (typeof input !== 'string') return { key: 'err.invalid' };
  let value = input.replace(/\r\n?/g, '\n').trim().normalize('NFC');
  if (!value) return { value, key: field.req ? 'err.req' : '' };
  if (field.opts) return { value, key: field.opts.includes(value) ? '' : 'err.invalid' };

  const max = field.type === 'textarea' ? 600 : 120;
  const lineControls = /[\x00-\x1f\x7f-\x9f\u2028-\u202e\u2066-\u2069]/;
  const textToCheck = field.type === 'textarea' ? value.replace(/[\n\t]/g, '') : value;
  if (value.length > max || lineControls.test(textToCheck)) return { value, key: 'err.invalid' };

  if (['firstName', 'lastName', 'country', 'city'].includes(field.k) && value.length < 2) {
    return { value, key: 'err.min' };
  }
  if (field.k === 'email' && !email.test(value)) return { value, key: 'err.email' };
  if (field.k === 'phone' || field.k === 'telegram') {
    value = value.replace(/[۰-۹]/g, digit => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(digit)))
      .replace(/[٠-٩]/g, digit => String('٠١٢٣٤٥٦٧٨٩'.indexOf(digit)));
    if (field.k === 'phone' && !phone(value)) return { value, key: 'err.phone' };
    if (field.k === 'telegram' && !phone(value) && !telegram.test(value)) return { value, key: 'err.tg' };
  }
  return { value, key: '' };
}
