import { FIELDS, validateField } from './form-fields.js';

(function () {
'use strict';
/* ============ SETTINGS: edit these values ============ */
var S = {
  email: 'ferasupport1@gmail.com',   // public contact address
  telegramChannel: '',               // e.g. 'https://t.me/yourchannel' or '@yourchannel'
  telegramContact: '',               // e.g. '@your_username' (shown after the test)
  instagram: '',                     // optional full link
  facebook: ''                       // optional full HTTPS link
};
document.documentElement.classList.add('js');
var $ = function (s, c) { return (c || document).querySelector(s); };
var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };
var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
var lang = 'en';
var EN = {};                    /* English texts, captured from the markup */

/* ====================== DARI TRANSLATIONS ====================== */
var FA = {
'splash.tag':'با اعتماد به نفس انگلیسی صحبت کنید',
'nav.programs':'برنامه‌ها','nav.levels':'سطح‌ها','nav.how':'چگونه کار می‌کند','nav.faq':'پرسش‌ها','nav.apply':'ثبت‌نام',
'hero.badge':'ثبت‌نام برای صنف‌های جدید آغاز شده است',
'hero.h1a':'انگلیسی را با','hero.h1b':'اعتماد به نفس','hero.h1c':'صحبت کنید',
'hero.lead':'صنف‌های زندهٔ آنلاین با استادان دلسوز و باتجربه و مسیری روشن، از نخستین واژه‌ها تا روانی در گفتار. ثبت‌نام کنید، آزمون تعیین سطح بدهید و به گروه تلگرامی صنف خود بپیوندید.',
'hero.cta1':'سفر انگلیسی‌ام را آغاز می‌کنم','hero.cta2':'چگونه کار می‌کند؟',
'hero.c1':'آزمون تعیین سطح رایگان','hero.c2':'گروه‌های کوچک و زنده','hero.c3':'زمان‌بندی انعطاف‌پذیر','hero.c4':'پشتیبانی در تلگرام',
'chat.title':'صنف زنده','chat.sub':'تمرین گفت‌وگو',
'fl.a1':'سطح شما: B1','fl.a2':'نتیجهٔ آزمون تعیین سطح','fl.b1':'گروه تلگرام','fl.b2':'تمرین روزانه',
'perk.1t':'صنف‌های زنده','perk.1d':'درس‌های تعاملی با استاد واقعی، نه ویدیوهای ضبط‌شده.',
'perk.2t':'گروه‌های کوچک','perk.2d':'شمار شاگردان کم است تا هر کس فرصت صحبت کردن داشته باشد.',
'perk.3t':'زمان‌های منعطف','perk.3d':'زمان صنف را مطابق برنامهٔ روزانهٔ خود انتخاب کنید.',
'perk.4t':'پشتیبانی تلگرامی','perk.4d':'تمرین، پرسش و یادآوری درس‌ها در گروه صنف شما.',
'prog.eyebrow':'برنامه‌ها','prog.h':'برنامه‌ای را انتخاب کنید که با هدف شما می‌خواند','prog.p':'هر برنامه با آزمون تعیین سطح آغاز می‌شود تا همیشه از سطح درست شروع کنید.',
'prog.1t':'انگلیسی عمومی','prog.1d':'پایه‌ای استوار در گرامر، واژگان، خواندن و شنیدن، از مبتدی تا پیشرفته.',
'prog.2t':'انگلیسی گفتاری','prog.2d':'تمرین روزانهٔ گفت‌وگو برای از بین بردن ترس از صحبت کردن و رسیدن به روانی.',
'prog.3t':'آیلتس و تافل','prog.3d':'آمادگی گام‌به‌گام برای آزمون‌های بین‌المللی، همراه با نمونه‌آزمون و بازخورد.',
'prog.4t':'انگلیسی کاری','prog.4d':'ایمیل، مصاحبهٔ کاری، جلسه و ارائه به زبان انگلیسیِ حرفه‌ای.',
'lv.eyebrow':'سطح‌ها','lv.h':'مسیری روشن از A1 تا C2','lv.p':'با استفاده از مقیاس CEFR، سطح آغاز شما را تخمین می‌زنیم.',
'lvn.A1':'مبتدی','lvn.A2':'ابتدایی','lvn.B1':'متوسط','lvn.B2':'بالاتر از متوسط','lvn.C1':'پیشرفته','lvn.C2':'مسلط',
'lvd.A1':'عبارت‌های آشنای روزمره را می‌فهمید و به کار می‌برید.',
'lvd.A2':'دربارهٔ زندگی روزمره، خانواده و نیازهای ساده صحبت می‌کنید.',
'lvd.B1':'در بیشتر موقعیت‌های سفر و کار مکالمه می‌کنید و نظر خود را بیان می‌کنید.',
'lvd.B2':'با گویشوران بومی دربارهٔ موضوع‌های گوناگون روان صحبت می‌کنید.',
'lvd.C1':'انگلیسی را برای تحصیل و کار حرفه‌ای به‌صورت منعطف به کار می‌برید.',
'lvd.C2':'تقریباً همه‌چیز را می‌فهمید و دقیق و طبیعی بیان می‌کنید.',
'how.eyebrow':'چگونه کار می‌کند','how.h':'چهار گام ساده تا نخستین صنف شما',
'how.1t':'فرم ثبت‌نام را پر کنید','how.1d':'معلومات و هدف آموزشی خود را در چند دقیقه وارد کنید.',
'how.2t':'آزمون تعیین سطح بدهید','how.2d':'۳۰ پرسش و حدود ۲۵ دقیقه. نتیجه بلافاصله نمایش داده می‌شود.',
'how.3t':'صنف خود را دریافت کنید','how.3d':'تیم ما شما را در گروهی جا می‌دهد که با سطح و زمان شما مطابقت دارد.',
'how.4t':'به تلگرام بپیوندید','how.4d':'برنامهٔ درسی، تمرین‌ها و اطلاعیه‌ها در گروه شما فرستاده می‌شود.',
'ap.eyebrow':'ثبت‌نام امروز','ap.h':'درخواست ثبت‌نام خود را آغاز کنید','ap.p':'معلومات خود را وارد کنید و سپس آزمون کوتاه تعیین سطح را بدهید. در مجموع حدود ۳۰ دقیقه وقت لازم است.',
'ap.a1h':'پیش از آغاز','ap.a1a':'ایمیل و شمارهٔ تماس معتبر وارد کنید.','ap.a1b':'نام کاربری یا شمارهٔ تلگرام خود را بنویسید تا شما را به گروه صنف اضافه کنیم.','ap.a1c':'جای آرامی پیدا کنید و حدود ۲۵ دقیقه وقت آزاد داشته باشید.',
'ap.a2h':'دربارهٔ آزمون تعیین سطح','ap.a2a':'۳۰ پرسش چندگزینه‌ای، از ساده تا پیشرفته.','ap.a2b':'۲۵ دقیقه؛ بدون دیکشنری و مترجم.','ap.a2c':'پس از آزمون، سطح تخمینی CEFR خود را می‌بینید.',
'ap.a3h':'حریم خصوصی','ap.a3a':'معلومات شما تنها برای ثبت‌نام و ارتباط دربارهٔ صنف‌ها استفاده می‌شود.',
'st.1':'معلومات شما','st.2':'آزمون تعیین سطح','st.3':'سطح شما',
'fm.h':'فرم ثبت‌نام شاگرد','fm.sub':'بخش‌های دارای ستاره (*) الزامی است.',
'g.personal':'معلومات شخصی','g.contact':'معلومات تماس','g.learning':'معلومات آموزشی',
'f.firstName':'نام','f.lastName':'تخلص','f.ageGroup':'گروه سنی','f.country':'کشور','f.city':'شهر',
'f.email':'آدرس ایمیل','f.phone':'شمارهٔ تماس','f.telegram':'شمارهٔ تلگرام یا نام کاربری',
'f.goal':'هدف اصلی شما','f.program':'برنامهٔ مورد علاقه','f.previous':'سابقهٔ آموزش انگلیسی','f.time':'زمان مناسب برای صنف','f.referral':'از کجا با ما آشنا شدید؟','f.message':'پیام (اختیاری)',
'ph.firstName':'مثلاً احمد','ph.lastName':'مثلاً احمدی','ph.country':'نام کشور را بنویسید','ph.city':'مثلاً هرات','ph.email':'name@example.com','ph.phone':'+93 700 000 000','ph.telegram':'@username یا +93…','ph.message':'اگر نکته‌ای هست که باید بدانیم، بنویسید',
'h.phone':'کد کشور را هم بنویسید.','h.telegram':'با همین شماره یا نام کاربری شما را به گروه صنف اضافه می‌کنیم.',
'o.ageGroup.0':'زیر ۱۵ سال','o.ageGroup.1':'۱۵ تا ۱۷ سال','o.ageGroup.2':'۱۸ تا ۲۴ سال','o.ageGroup.3':'۲۵ تا ۳۴ سال','o.ageGroup.4':'۳۵ سال و بالاتر',
'o.goal.0':'کار و پیشرفت شغلی','o.goal.1':'تحصیل در خارج یا بورسیه','o.goal.2':'آزمون آیلتس / تافل','o.goal.3':'سفر یا زندگی در خارج','o.goal.4':'گفت‌وگوی روزمره','o.goal.5':'موارد دیگر',
'o.program.0':'انگلیسی عمومی','o.program.1':'انگلیسی گفتاری','o.program.2':'آیلتس و تافل','o.program.3':'انگلیسی کاری','o.program.4':'درس خصوصی (یک‌به‌یک)','o.program.5':'هنوز مطمئن نیستم',
'o.previous.0':'تاکنون انگلیسی نخوانده‌ام','o.previous.1':'کمتر از یک سال','o.previous.2':'یک تا سه سال','o.previous.3':'بیشتر از سه سال',
'o.time.0':'صبح','o.time.1':'بعدازظهر','o.time.2':'شام','o.time.3':'آخر هفته','o.time.4':'هر زمان',
'o.referral.0':'تلگرام','o.referral.1':'انستاگرام','o.referral.2':'فیسبوک','o.referral.3':'دوست یا اعضای خانواده','o.referral.4':'موارد دیگر',
'fm.consent':'تأیید می‌کنم که معلومات واردشده درست است و موافقم که آکادمی دربارهٔ ثبت‌نام من با من تماس بگیرد.',
'fm.preview':'این نسخه برای دیدن وب‌سایت است. برای ثبت‌نام و آزمون، لینک نشرشده در Vercel را باز کنید.',
'fm.submit':'ادامه به آزمون تعیین سطح','fm.note':'معلومات و نتیجهٔ آزمون شما را برای ثبت‌نام و تعیین صنف به ایمیل آکادمی می‌فرستیم.',
'rd.h':'معلومات شما آماده است','rd.p':'گام بعدی آزمون تعیین سطح است. این آزمون مشخص می‌کند کدام صنف برای شما مناسب‌تر است.','rd.f1':'۳۰ پرسش','rd.f2':'۲۵ دقیقه','rd.btn':'شروع آزمون تعیین سطح','rd.edit':'ویرایش معلومات',
'dn.h':'نتیجهٔ آزمون شما','dn.view':'دیدن نتیجه','dn.tg':'پیوستن به تلگرام',
'faq.eyebrow':'پرسش‌ها','faq.h':'پرسش‌های رایج شاگردان',
'faq.1q':'آیا باید از قبل انگلیسی بلد باشم؟','faq.1a':'نه. برای کسانی که هیچ نمی‌دانند، صنف مبتدی (A1) داریم و آزمون تعیین سطح، سطح مناسب شما را مشخص می‌کند.',
'faq.2q':'صنف‌های آنلاین چگونه برگزار می‌شوند؟','faq.2a':'صنف‌ها به‌صورت زنده و ویدیویی برگزار می‌شوند. مواد درسی، تمرین‌ها و اطلاعیه‌ها در گروه تلگرام شما قرار می‌گیرد.',
'faq.3q':'آزمون تعیین سطح چقدر وقت می‌گیرد؟','faq.3a':'آزمون ۳۰ پرسش دارد و حدود ۲۵ دقیقه طول می‌کشد. سطح شما بلافاصله پس از پایان آزمون نمایش داده می‌شود.',
'faq.4q':'پس از ثبت‌نام چه می‌شود؟','faq.4a':'معلومات و نتیجهٔ آزمون شما به ایمیل تیم ما می‌رسد. ما از طریق تلگرام با شما تماس می‌گیریم و شما را در گروهی جا می‌دهیم که با سطح و زمان مناسب شما مطابقت دارد.',
'faq.5q':'آیا می‌توانم به‌صورت خصوصی (یک‌به‌یک) درس بخوانم؟','faq.5a':'بلی. در فرم ثبت‌نام گزینهٔ «درس خصوصی» را انتخاب کنید تا برای شما ترتیب بدهیم.',
'ft.tag':'صنف‌های زندهٔ آنلاین انگلیسی با مسیری روشن تا روانی در گفتار.','ft.explore':'بخش‌ها','ft.contact':'تماس','ft.copy':'© ۲۰۲۶ آکادمی زبان فرا. تمام حقوق محفوظ است.',
'st.cta':'ثبت‌نام',
'ex.title':'آزمون تعیین سطح','ex.sub':'آکادمی زبان فرا','ex.exit':'خروج',
'ex.ih':'پیش از شروع','ex.ip':'این نکته‌ها را با دقت بخوانید. زمان‌سنج با فشردن دکمهٔ شروع آغاز می‌شود.',
'ex.r1':'۳۰ پرسش چندگزینه‌ای، از ساده تا دشوار.','ex.r2':'در مجموع ۲۵ دقیقه وقت دارید.','ex.r3':'تنها کار کنید. از دیکشنری، مترجم یا کمک دیگران استفاده نکنید.','ex.r4':'پیش از پایان آزمون می‌توانید به پرسش‌های قبلی برگردید و پاسخ‌ها را تغییر بدهید.','ex.r5':'صفحه را نبندید و در جریان آزمون آن را دوباره بارگذاری نکنید.',
'ex.begin':'شروع آزمون','ex.prev':'قبلی','ex.next':'بعدی',
'rs.title':'نتیجهٔ آزمون تعیین سطح','rs.cefr':'سطح تخمینی CEFR','rs.score':'امتیاز','rs.pct':'درستی پاسخ‌ها','rs.time':'زمان مصرف‌شده',
'rs.next':'تیم ما از طریق تلگرام با شما تماس می‌گیرد و شما را در گروهی جا می‌دهد که با سطح و زمان مناسب شما مطابقت دارد.',
'rs.print':'چاپ / ذخیره به‌صورت PDF','rs.close':'بازگشت به وب‌سایت',
/* dynamic strings */
'meta.title':'آکادمی زبان فرا | یادگیری آنلاین زبان انگلیسی',
'f.select':'انتخاب کنید…',
'err.req':'این بخش الزامی است.','err.min':'دست‌کم دو حرف وارد کنید.','err.email':'یک آدرس ایمیل معتبر وارد کنید.','err.phone':'شمارهٔ معتبر را همراه با کد کشور وارد کنید.','err.tg':'نام کاربری تلگرام (مثلاً @name) یا شمارهٔ تلفن وارد کنید.','err.consent':'برای ادامه، لطفاً این بخش را تأیید کنید.',
'ex.qof':'پرسش {n} از {t}','ex.ans':'{n} پاسخ ثبت شده','ex.finish':'پایان آزمون',
'm.unT':'پرسش‌های بدون پاسخ','m.unP':'{n} پرسش بدون پاسخ دارید. آیا می‌خواهید با همین وضعیت آزمون را پایان بدهید؟','m.review':'بازبینی پرسش‌ها','m.finish':'پایان آزمون',
'm.exitT':'از آزمون خارج می‌شوید؟','m.exitP':'پاسخ‌های شما از بین می‌رود و باید آزمون را دوباره آغاز کنید.','m.stay':'ادامهٔ آزمون','m.exit':'خروج',
'err.invalid':'لطفاً معلومات درست وارد کنید.',
'reg.wait':'در حال ثبت معلومات…','reg.invalid':'معلومات و تأیید فرم را دوباره بررسی کنید.',
'reg.bad':'ثبت‌نام انجام نشد. لطفاً دوباره کوشش کنید.','reg.expired':'مهلت این ثبت‌نام پایان یافته است. لطفاً فورم را دوباره بفرستید.',
'net.rate':'درخواست‌ها زیاد است. کمی منتظر بمانید و دوباره کوشش کنید.',
'ex.loading':'در حال آماده‌کردن آزمون…','ex.loadBad':'آزمون باز نشد. لطفاً دوباره کوشش کنید.',
'sb.h':'ارسال آزمون','sb.retry':'ارسال دوبارهٔ آزمون','sb.restart':'شروع آزمون جدید',
'sb.bad':'پاسخ‌ها ارسال نشد. اتصال اینترنت را بررسی کنید و دوباره کوشش کنید.',
'sb.expired':'مهلت ارسال این آزمون تمام شده است. لطفاً آزمون جدیدی را شروع کنید.',
'rs.retry':'تلاش دوباره برای ارسال',
'mail.wait':'در حال ارسال…','mail.ok1':'معلومات شما برای تیم ما ارسال شد.','mail.okR':'درخواست و نتیجهٔ شما برای تیم ما ارسال شد.',
'mail.bad1':'ایمیل ثبت‌نام ارسال نشد. معلومات شما همراه با نتیجهٔ آزمون دوباره فرستاده می‌شود.',
'mail.bad':'ایمیل نتیجه ارسال نشد. این صفحه را باز بگذارید و دوباره کوشش کنید.',
'mail.expired':'مهلت ارسال دوباره پایان یافته است. با آکادمی تماس بگیرید و شمارهٔ پیگیری را بگویید.',
'rs.ref':'شمارهٔ پیگیری: {ref}',
'dn.text':'{name} عزیز، سطح تخمینی شما {lv} ({lvn}) است.',
'dn.f1':'سطح {lv}','dn.f2':'امتیاز {s} از {t}'
};
var EN_DYN = {
'meta.title':'Fera Language Academy | Learn English Online',
'f.select':'Select…',
'err.req':'This field is required.','err.min':'Please enter at least 2 characters.','err.email':'Enter a valid email address.','err.phone':'Enter a valid phone number with country code.','err.tg':'Enter a Telegram username (e.g. @name) or a phone number.','err.consent':'Please confirm to continue.',
'ex.qof':'Question {n} of {t}','ex.ans':'{n} answered','ex.finish':'Finish test',
'm.unT':'Unanswered questions','m.unP':'You have {n} unanswered question(s). Do you want to finish anyway?','m.review':'Review questions','m.finish':'Finish test',
'm.exitT':'Exit the test?','m.exitP':'Your answers will be lost and you will need to start the test again.','m.stay':'Continue test','m.exit':'Exit',
'err.invalid':'Enter a valid value.',
'reg.wait':'Registering your details…','reg.invalid':'Check your information and the consent box, then try again.',
'reg.bad':'Registration could not be submitted. Please try again.','reg.expired':'Your registration session expired. Please submit your details again.',
'net.rate':'Too many requests. Wait a moment and try again.',
'ex.loading':'Loading the test…','ex.loadBad':'The test could not be loaded. Please try again.',
'sb.bad':'Your answers could not be submitted. Check your connection and try again.',
'sb.expired':'This test can no longer be submitted. Please start a new test.',
'mail.wait':'Sending…','mail.ok1':'Your details were sent to our team.','mail.okR':'Your application and result were sent to our team.',
'mail.bad1':'The registration email could not be sent. We will try again with your placement result.',
'mail.bad':'The result email could not be sent. Keep this page open and retry sending.',
'mail.expired':'The email retry window has ended. Contact the academy and give them your reference.',
'rs.ref':'Reference: {ref}',
'dn.text':'{name}, your estimated level is {lv} ({lvn}).',
'dn.f1':'Level {lv}','dn.f2':'Score {s} of {t}'
};
function t(k, v) {
  var s = lang === 'fa' ? FA[k] : (EN[k] !== undefined ? EN[k] : EN_DYN[k]);
  if (s === undefined) s = EN[k] !== undefined ? EN[k] : (EN_DYN[k] || k);
  if (v) Object.keys(v).forEach(function (x) { s = s.split('{' + x + '}').join(v[x]); });
  return s;
}
function fmt(n) {
  n = String(n);
  return lang === 'fa' ? n.replace(/\d/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹'[d]; }) : n;
}

/* ====================== LEVELS ====================== */
var LEVELS = [['A1','Beginner','Understand and use familiar everyday phrases.'],
['A2','Elementary','Talk about daily life, family and simple needs.'],
['B1','Intermediate','Handle most travel and work situations and share your opinions.'],
['B2','Upper-Intermediate','Speak fluently with native speakers on many topics.'],
['C1','Advanced','Use English flexibly for study and professional life.'],
['C2','Proficient','Understand almost everything and express yourself precisely.']];
(function () {
  var g = $('#levelGrid'), h = '';
  LEVELS.forEach(function (l) {
    h += '<div class="lv reveal"><b>' + l[0] + '</b><h3 data-i18n="lvn.' + l[0] + '">' + l[1] + '</h3><p data-i18n="lvd.' + l[0] + '">' + l[2] + '</p></div>';
  });
  g.innerHTML = h;
  $$('.lv', g).forEach(function (tile, i) {
    tile.style.setProperty('--h', (22 + i * 14) + '%');
    tile.style.setProperty('--rd', (i * .07).toFixed(2) + 's');
  });
})();

/* ====================== FORM SCHEMA ====================== */
var COUNTRIES = ['Afghanistan','Australia','Canada','Denmark','Finland','France','Germany','India','Iran','Italy','Kazakhstan','Netherlands','Norway','Pakistan','Qatar','Russia','Saudi Arabia','Sweden','Tajikistan','Turkey','Turkmenistan','United Arab Emirates','United Kingdom','United States','Uzbekistan','Other'];
function esc(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
(function () {
  $$('[data-fields]').forEach(function (box) {
    var html = '';
    FIELDS[box.dataset.fields].forEach(function (f) {
      var id = 'f_' + f.k, c = f.full ? ' full' : '';
      html += '<div class="field' + c + '" data-k="' + f.k + '"><label for="' + id + '"><span data-i18n="f.' + f.k + '">' + esc(f.en) + '</span>' + (f.req ? '<em>*</em>' : '') + '</label>';
      if (f.type === 'select') {
        html += '<select id="' + id + '" name="' + f.k + '"><option value="" data-i18n="f.select">Select…</option>';
        f.opts.forEach(function (o, i) { html += '<option value="' + esc(o) + '" data-i18n="o.' + f.k + '.' + i + '">' + esc(o) + '</option>'; });
        html += '</select>';
      } else if (f.type === 'textarea') {
        html += '<textarea id="' + id + '" name="' + f.k + '" maxlength="600" data-i18n-ph="ph.' + f.k + '" placeholder="' + esc(f.ph || '') + '"></textarea>';
      } else {
        html += '<input id="' + id + '" name="' + f.k + '" type="' + f.type + '"' + (f.ac ? ' autocomplete="' + f.ac + '"' : '') + (f.list ? ' list="' + f.list + '"' : '') + (f.ltr ? ' dir="ltr"' : '') + ' data-i18n-ph="ph.' + f.k + '" placeholder="' + esc(f.ph || '') + '" maxlength="120">';
      }
      if (f.hint) html += '<span class="hint" data-i18n="h.' + f.k + '">' + esc(f.hint) + '</span>';
      html += '<span class="err" role="alert"></span></div>';
    });
    box.innerHTML = html;
  });
  var dl = document.createElement('datalist'); dl.id = 'countries';
  dl.innerHTML = COUNTRIES.map(function (c) { return '<option value="' + c + '">'; }).join('');
  document.body.appendChild(dl);
})();

/* capture English texts from the markup (before any translation) */
$$('[data-i18n]').forEach(function (el) { EN[el.dataset.i18n] = el.textContent; });
$$('[data-i18n-ph]').forEach(function (el) { EN[el.dataset.i18nPh] = el.getAttribute('placeholder') || ''; });

/* ====================== LANGUAGE ====================== */
var dynHooks = [];
function applyLang(l, save) {
  lang = l === 'fa' ? 'fa' : 'en';
  var h = document.documentElement;
  h.lang = lang === 'fa' ? 'fa-AF' : 'en';
  h.dir = lang === 'fa' ? 'rtl' : 'ltr';
  $$('[data-i18n]').forEach(function (el) { el.textContent = t(el.dataset.i18n); });
  $$('[data-i18n-ph]').forEach(function (el) { el.setAttribute('placeholder', t(el.dataset.i18nPh)); });
  $$('.lang button').forEach(function (b) { b.setAttribute('aria-pressed', String(b.dataset.lang === lang)); });
  $$('.step .n').forEach(function (n, i) { n.textContent = fmt(i + 1); });
  $$('.stepper li span').forEach(function (n, i) { n.textContent = fmt(i + 1); });
  $$('.err[data-ek]').forEach(function (e) { e.textContent = t(e.dataset.ek); });
  document.title = t('meta.title');
  if (save) { try { localStorage.setItem('fera_lang', lang); } catch (e) {} }
  dynHooks.forEach(function (fn) { fn(); });
}
(function () {
  var q = /[?&]lang=(fa|en)(?:&|$)/.exec(location.search), saved = null, start = 'en';
  try { saved = localStorage.getItem('fera_lang'); } catch (e) {}
  if (q) start = q[1];
  else if (saved) start = saved;
  else if (/^(fa|prs)/i.test(navigator.language || '')) start = 'fa';
  $$('.lang button').forEach(function (b) { b.addEventListener('click', function () { applyLang(b.dataset.lang, true); }); });
  window.__startLang = start;
})();

/* ====================== SETTINGS-DRIVEN LINKS ====================== */
function httpsUrl(value, hostname) {
  try {
    var url = new URL(value);
    return url.protocol === 'https:' && !url.username && !url.password &&
      (!hostname || url.hostname === hostname) ? url.href : '';
  } catch (error) { return ''; }
}
function tgUrl(value) {
  var v = value.trim();
  if (!v) return '';
  if (!/^https?:\/\//i.test(v)) v = 'https://t.me/' + v.replace(/^@/, '').replace(/^t\.me\//i, '');
  return httpsUrl(v, 't.me');
}
var TG_CHANNEL = tgUrl(S.telegramChannel), TG_CONTACT = tgUrl(S.telegramContact);
var TG_ANY = TG_CHANNEL || TG_CONTACT;
(function () {
  var fab = $('#tgfab');
  if (TG_ANY) { fab.href = TG_ANY; fab.classList.add('on'); }
  var ul = $('#footContacts'), h = '';
  if (S.email) h += '<li><a href="mailto:' + esc(S.email) + '"><svg class="ico"><use href="#i-mail"/></svg><span dir="ltr">' + esc(S.email) + '</span></a></li>';
  if (TG_CONTACT) h += '<li><a href="' + esc(TG_CONTACT) + '" target="_blank" rel="noopener"><svg class="ico"><use href="#i-send"/></svg><span dir="ltr">Telegram' + (S.telegramContact && !/^https?:/.test(S.telegramContact) ? ' · ' + esc(S.telegramContact) : '') + '</span></a></li>';
  if (TG_CHANNEL) h += '<li><a href="' + esc(TG_CHANNEL) + '" target="_blank" rel="noopener"><svg class="ico"><use href="#i-send"/></svg><span>Telegram channel</span></a></li>';
  var instagram = httpsUrl(S.instagram), facebook = httpsUrl(S.facebook);
  if (instagram) h += '<li><a href="' + esc(instagram) + '" target="_blank" rel="noopener"><svg class="ico"><use href="#i-arrow"/></svg><span>Instagram</span></a></li>';
  if (facebook) h += '<li><a href="' + esc(facebook) + '" target="_blank" rel="noopener"><svg class="ico"><use href="#i-arrow"/></svg><span>Facebook</span></a></li>';
  ul.innerHTML = h;
  [['#doneTg'], ['#resTg']].forEach(function (a) { var el = $(a[0]); if (TG_ANY) { el.href = TG_ANY; el.hidden = false; } });
})();

/* ====================== LOGO INTRO ====================== */
(function () {
  var sp = $('#splash');
  if (!sp) return;
  document.body.classList.add('splashing');
  var stage = $('#stage'), img = $('#splashImg'), over = false;
  function finish() {
    if (over) return; over = true;
    document.body.classList.remove('splashing');
    sp.classList.add('hide');
    setTimeout(function () { sp.remove(); }, 1200);
  }
  sp.addEventListener('click', finish);
  setTimeout(finish, 5200);
  if (reduce) { sp.classList.add('done'); setTimeout(finish, 800); return; }
  sp.style.setProperty('--src', 'url("' + img.getAttribute('src') + '")');
  var cols = 10, rows = 5, seed = 11;
  function rnd() { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; }
  var frag = document.createDocumentFragment();
  for (var r = 0; r < rows; r++) for (var c = 0; c < cols; c++) {
    var d = document.createElement('i'), s = d.style;
    d.className = 'tile';
    s.left = (c * 100 / cols) + '%'; s.top = (r * 100 / rows) + '%';
    s.width = (100 / cols + .15) + '%'; s.height = (100 / rows + .15) + '%';
    s.backgroundSize = (cols * 100) + '% ' + (rows * 100) + '%';
    s.backgroundPosition = (c / (cols - 1) * 100) + '% ' + (r / (rows - 1) * 100) + '%';
    s.setProperty('--dx', Math.round((rnd() - .5) * 1100) + 'px');
    s.setProperty('--dy', Math.round((rnd() - .5) * 800) + 'px');
    s.setProperty('--rot', Math.round((rnd() - .5) * 420) + 'deg');
    s.setProperty('--d', (c / cols * .55 + rnd() * .5 + .1).toFixed(2) + 's');
    frag.appendChild(d);
  }
  stage.insertBefore(frag, img);
  setTimeout(function () { sp.classList.add('done'); }, 2050);
  setTimeout(finish, 3500);
})();

/* ====================== NAV, SCROLL, REVEAL ====================== */
var hdr = $('#hdr'), bar = $('#progress'), sticky = $('#sticky'), applySec = $('#apply');
function setMenu(open) {
  document.body.classList.toggle('nav-open', open);
  $('#burger').setAttribute('aria-expanded', String(open));
}
$('#burger').addEventListener('click', function () { setMenu(!document.body.classList.contains('nav-open')); });
$('#navClose').addEventListener('click', function () { setMenu(false); });
$('#scrim').addEventListener('click', function () { setMenu(false); });
$$('#nav a').forEach(function (a) { a.addEventListener('click', function () { setMenu(false); }); });
document.addEventListener('keydown', function (e) { if (e.key === 'Escape') setMenu(false); });
function onScroll() {
  var y = window.scrollY;
  hdr.classList.toggle('scrolled', y > 20);
  var max = document.documentElement.scrollHeight - window.innerHeight;
  bar.style.width = (max > 0 ? y / max * 100 : 0) + '%';
  var r = applySec.getBoundingClientRect();
  var inApply = r.top < window.innerHeight * .8 && r.bottom > 0;
  var show = y > 520 && !inApply;
  sticky.classList.toggle('show', show);
  document.body.classList.toggle('has-sticky', show);
}
window.addEventListener('scroll', onScroll, { passive: true });
window.addEventListener('resize', onScroll);
onScroll();
if ('IntersectionObserver' in window) {
  var io = new IntersectionObserver(function (es) {
    es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } });
  }, { threshold: .12, rootMargin: '0px 0px -40px 0px' });
  $$('.reveal').forEach(function (el) { io.observe(el); });
} else { $$('.reveal').forEach(function (el) { el.classList.add('in'); }); }

/* ====================== HERO CHAT ====================== */
(function () {
  var chat = $('#chatBody');
  var script = [['t', 'Hi! Welcome to class. What is your name?'], ['s', 'Hello! My name is Sara.'], ['t', 'Nice to meet you, Sara! Why do you want to learn English?'], ['s', 'I want a better job and to travel.'], ['t', 'Great goals! You are speaking really well. ✨']];
  function add(type, text) { var d = document.createElement('div'); d.className = 'msg msg--' + type; d.textContent = text; chat.appendChild(d); }
  function run() {
    chat.innerHTML = ''; var i = 0;
    (function next() {
      if (i >= script.length) { setTimeout(run, 4200); return; }
      var m = script[i++], ty = document.createElement('div');
      ty.className = 'msg msg--' + m[0] + ' msg--typing'; ty.innerHTML = '<i></i><i></i><i></i>'; chat.appendChild(ty);
      setTimeout(function () { ty.remove(); add(m[0], m[1]); setTimeout(next, 900); }, 1100);
    })();
  }
  if (reduce) script.forEach(function (m) { add(m[0], m[1]); }); else run();
})();

/* ====================== FAQ ====================== */
$$('#faqList .qa').forEach(function (qa) {
  var b = $('button', qa);
  b.addEventListener('click', function () {
    var open = !qa.classList.contains('open');
    $$('#faqList .qa').forEach(function (o) { o.classList.remove('open'); $('button', o).setAttribute('aria-expanded', 'false'); });
    if (open) { qa.classList.add('open'); b.setAttribute('aria-expanded', 'true'); }
  });
});

var LETTERS = 'ABCD';

/* ====================== PLACEMENT API ====================== */
async function placement(action, data) {
  var controller = new AbortController();
  var timeout = setTimeout(function () { controller.abort(); }, 33000);
  try {
    var response = await fetch('/api/placement', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify(Object.assign({ action: action }, data)),
      signal: controller.signal,
      mode: 'same-origin',
      redirect: 'error',
      credentials: 'omit',
      cache: 'no-store'
    });
    var body = await response.json().catch(function () { return {}; });
    if (!response.ok) return { error: response.status === 429 ? 'rate' : (body.error || 'network') };
    return body;
  } catch (error) {
    return { error: 'network' };
  } finally {
    clearTimeout(timeout);
  }
}

function setStatus(element, key, state) {
  element.dataset.mk = key;
  element.classList.remove('wait', 'ok', 'bad');
  if (state) element.classList.add(state);
  element.textContent = key ? t(key) : '';
}
dynHooks.push(function () {
  $$('.mailstate[data-mk]').forEach(function (el) {
    el.textContent = el.dataset.mk ? t(el.dataset.mk) : '';
  });
});

/* ====================== APPLICATION FORM ====================== */
var ST = {
  app: null, ref: '', registration: '', registrationId: '', fingerprint: '',
  questions: [], attempt: '', answers: [], order: [], idx: 0, deadline: 0,
  timer: null, running: false, starting: false, submitting: false,
  pending: false, submitted: null, retry: '', result: null, emailSent: false
};
var form = $('#appForm');
var exam = $('#exam');
var localPreview = location.protocol === 'file:';
if (localPreview) {
  $('#previewNote').hidden = false;
  $$('input, select, textarea, button', form).forEach(function (control) {
    control.disabled = true;
  });
}

function setStep(n) {
  $$('#stepper li').forEach(function (li, i) {
    li.classList.toggle('ok', i < n - 1);
    li.classList.toggle('on', i === n - 1);
  });
}

function showPane(id) {
  ['paneForm', 'paneReady', 'paneDone'].forEach(function (p) { $('#' + p).hidden = p !== id; });
}

function setErr(wrap, key) {
  wrap.classList.toggle('invalid', !!key);
  $('input, select, textarea', wrap).setAttribute('aria-invalid', String(!!key));
  var error = $('.err', wrap);
  if (key) { error.dataset.ek = key; error.textContent = t(key); }
  else { delete error.dataset.ek; error.textContent = ''; }
}

function validate() {
  var first = null, vals = {};
  Object.values(FIELDS).flat().forEach(function (field) {
    var input = form.elements.namedItem(field.k);
    var wrap = input.closest('.field');
    var checked = validateField(field, input.value);
    setErr(wrap, checked.key);
    if (checked.key && !first) first = input;
    vals[field.k] = checked.value;
  });
  var consent = $('#consent');
  $('#consentRow').classList.toggle('invalid', !consent.checked);
  consent.setAttribute('aria-invalid', String(!consent.checked));
  if (!consent.checked && !first) first = consent;
  vals.language = lang === 'fa' ? 'Dari' : 'English';
  return { first: first, vals: vals };
}

$$('#appForm input,#appForm select,#appForm textarea').forEach(function (el) {
  el.addEventListener(el.tagName === 'SELECT' ? 'change' : 'input', function () {
    var wrap = el.closest('.field');
    if (wrap && wrap.classList.contains('invalid')) setErr(wrap, '');
    if (el.id === 'consent') {
      $('#consentRow').classList.remove('invalid');
      el.setAttribute('aria-invalid', 'false');
    }
  });
});

function editApplication() {
  showPane('paneForm');
  setStep(1);
  form.elements.namedItem('firstName').focus({ preventScroll: true });
}

form.addEventListener('submit', async function (event) {
  event.preventDefault();
  var button = $('button[type="submit"]', form);
  if (localPreview || button.disabled) return;
  var checked = validate();
  setStatus($('#formState'), '');
  if (checked.first) {
    var wrap = checked.first.closest('.field') || checked.first.closest('.check');
    wrap.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'center' });
    checked.first.focus({ preventScroll: true });
    if (checked.first.id === 'consent') setStatus($('#formState'), 'err.consent', 'bad');
    return;
  }

  var fingerprint = JSON.stringify(checked.vals);
  if (fingerprint !== ST.fingerprint) {
    ST.fingerprint = fingerprint;
    ST.registrationId = crypto.randomUUID();
  }
  button.disabled = true;
  setStatus($('#formState'), 'reg.wait', 'wait');
  var reply = await placement('register', {
    app: checked.vals,
    consent: $('#consent').checked,
    honeypot: form.elements.namedItem('_honey').value,
    registrationId: ST.registrationId
  });
  button.disabled = false;
  if (!reply.registration) {
    var key = reply.error === 'invalid' ? 'reg.invalid' :
      reply.error === 'rate' ? 'net.rate' : 'reg.bad';
    setStatus($('#formState'), key, 'bad');
    return;
  }

  ST.app = checked.vals;
  ST.ref = reply.ref;
  ST.registration = reply.registration;
  setStatus($('#formState'), '');
  setStatus($('#mailState1'), reply.emailSent ? 'mail.ok1' : 'mail.bad1', reply.emailSent ? 'ok' : 'bad');
  showPane('paneReady');
  setStep(2);
  openExam();
});

$('#editDetails').addEventListener('click', editApplication);
$('#startTest').addEventListener('click', openExam);

/* ====================== PLACEMENT TEST ====================== */
function screen(id) {
  ['scrIntro', 'scrQ', 'scrSubmit', 'scrRes'].forEach(function (s) { $('#' + s).hidden = s !== id; });
  $('#examMain').scrollTop = 0;
}

function mmss(seconds) {
  var s = Math.max(0, Math.round(seconds));
  return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
}

function shuffle(a) {
  for (var i = a.length - 1; i > 0; i--) {
    var j = Math.floor(Math.random() * (i + 1)), x = a[i];
    a[i] = a[j];
    a[j] = x;
  }
  return a;
}

function candInfo() {
  var a = ST.app, target = $('#candInfo');
  var values = [a.firstName + ' ' + a.lastName, a.email, a.city + ', ' + a.country];
  target.replaceChildren();
  values.forEach(function (value, index) {
    var span = document.createElement('span');
    if (index === 1) span.dir = 'ltr';
    span.textContent = value;
    target.appendChild(span);
  });
}

function openExam() {
  if (!ST.app) return;
  exam.classList.add('open');
  document.body.classList.add('exam-open');
  if (ST.result) { showResult(); return; }
  if (ST.pending) { screen('scrSubmit'); return; }
  candInfo();
  screen('scrIntro');
  setStatus($('#startState'), '');
  $('#timer').hidden = true;
  $('#examProg').style.width = '0';
  $('#beginBtn').focus({ preventScroll: true });
}

function closeExam() {
  exam.classList.remove('open');
  document.body.classList.remove('exam-open');
  $('#modal').hidden = true;
  $('#startTest').focus({ preventScroll: true });
}

function modal(o) {
  $('#mTitle').textContent = o.title;
  $('#mText').textContent = o.text;
  var y = $('#mYes'), n = $('#mNo');
  y.textContent = o.yes;
  n.textContent = o.no;
  n.hidden = !o.no;
  y.onclick = function () { $('#modal').hidden = true; if (o.onYes) o.onYes(); };
  n.onclick = function () { $('#modal').hidden = true; };
  $('#modal').hidden = false;
  y.focus();
}

function answered() {
  return ST.answers.filter(function (answer) { return answer !== null; }).length;
}

$('#beginBtn').addEventListener('click', async function () {
  if (ST.starting) return;
  var button = $('#beginBtn');
  ST.starting = button.disabled = $('#exitExam').disabled = true;
  setStatus($('#startState'), 'ex.loading', 'wait');
  var reply = await placement('start', { registration: ST.registration });
  ST.starting = button.disabled = $('#exitExam').disabled = false;
  if (!reply.attempt) {
    if (reply.error === 'registrationExpired') {
      closeExam();
      editApplication();
      setStatus($('#formState'), 'reg.expired', 'bad');
    } else {
      setStatus($('#startState'), reply.error === 'rate' ? 'net.rate' : 'ex.loadBad', 'bad');
    }
    return;
  }

  ST.questions = reply.questions;
  ST.attempt = reply.attempt;
  ST.answers = Array(ST.questions.length).fill(null);
  ST.order = ST.questions.map(function () { return shuffle([0, 1, 2, 3]); });
  ST.idx = 0;
  ST.deadline = performance.now() + reply.duration * 1000;
  ST.running = true;
  $('#timer').hidden = false;
  ST.timer = setInterval(tick, 250);
  screen('scrQ');
  renderQ();
  tick();
});

function tick() {
  if (!ST.running) return;
  var remaining = Math.max(0, Math.ceil((ST.deadline - performance.now()) / 1000));
  $('#timeLeft').textContent = mmss(remaining);
  $('#timer').classList.toggle('low', remaining <= 120);
  if (remaining === 0) finishTest();
}

function renderQ() {
  if (!ST.running) return;
  var i = ST.idx, q = ST.questions[i], total = ST.questions.length;
  $('#qCount').textContent = t('ex.qof', { n: fmt(i + 1), t: fmt(total) });
  $('#qLevelHint').textContent = t('ex.ans', { n: fmt(answered()) });
  $('#qText').textContent = q.q.replace('___', '_____');
  var h = '';
  ST.order[i].forEach(function (oi, j) {
    var selected = ST.answers[i] === oi;
    h += '<button type="button" class="opt' + (selected ? ' sel' : '') +
      '" data-oi="' + oi + '" aria-pressed="' + selected + '"><span class="k">' + LETTERS[j] +
      '</span><span>' + esc(q.o[oi]) + '</span></button>';
  });
  $('#qOpts').innerHTML = h;
  $('#prevBtn').style.visibility = i === 0 ? 'hidden' : 'visible';
  $('#nextLbl').textContent = i === total - 1 ? t('ex.finish') : t('ex.next');
  var dots = '';
  for (var k = 0; k < total; k++) {
    dots += '<button type="button" data-i="' + k + '" class="' +
      (ST.answers[k] !== null ? 'ans ' : '') + (k === i ? 'cur' : '') +
      '" aria-label="' + (k + 1) + '">' + (k + 1) + '</button>';
  }
  $('#qDots').innerHTML = dots;
  $('#examProg').style.width = (answered() / total * 100) + '%';
}

dynHooks.push(function () {
  if (ST.running) renderQ();
  if (ST.result) { fillResult(); updateDone(); }
});
$('#qOpts').addEventListener('click', function (event) {
  var button = event.target.closest('.opt');
  if (!button || !ST.running) return;
  tick();
  if (!ST.running) return;
  ST.answers[ST.idx] = Number(button.dataset.oi);
  renderQ();
});
$('#qDots').addEventListener('click', function (event) {
  var button = event.target.closest('button');
  if (!button || !ST.running) return;
  ST.idx = Number(button.dataset.i);
  renderQ();
  $('#examMain').scrollTop = 0;
});
$('#prevBtn').addEventListener('click', function () {
  if (!ST.running || ST.idx === 0) return;
  ST.idx--;
  renderQ();
  $('#examMain').scrollTop = 0;
});
$('#nextBtn').addEventListener('click', function () {
  if (!ST.running) return;
  tick();
  if (!ST.running) return;
  var total = ST.questions.length;
  if (ST.idx < total - 1) {
    ST.idx++;
    renderQ();
    $('#examMain').scrollTop = 0;
    return;
  }
  var left = total - answered();
  if (left) {
    modal({
      title: t('m.unT'), text: t('m.unP', { n: fmt(left) }),
      yes: t('m.finish'), no: t('m.review'), onYes: finishTest
    });
  } else {
    finishTest();
  }
});
$('#exitExam').addEventListener('click', function () {
  if (ST.submitting || ST.starting) return;
  if (ST.result) { closeResult(); return; }
  if (ST.running) {
    modal({
      title: t('m.exitT'), text: t('m.exitP'), yes: t('m.exit'), no: t('m.stay'),
      onYes: function () {
        ST.running = false;
        clearInterval(ST.timer);
        ST.answers = [];
        closeExam();
      }
    });
  } else closeExam();
});
window.addEventListener('beforeunload', function (event) {
  if (ST.running || ST.pending || (ST.result && !ST.emailSent)) {
    event.preventDefault();
    event.returnValue = '';
  }
});

function finishTest() {
  if (!ST.running) return;
  ST.running = false;
  clearInterval(ST.timer);
  $('#modal').hidden = true;
  $('#timer').hidden = true;
  ST.pending = true;
  ST.submitted = ST.answers.slice();
  screen('scrSubmit');
  submitTest();
}

async function submitTest() {
  if (ST.submitting) return;
  ST.submitting = true;
  $('#exitExam').disabled = true;
  $('#retrySubmit').hidden = true;
  $('#restartTest').hidden = true;
  $('#retryMail').hidden = true;

  var status = ST.result ? $('#mailState2') : $('#submitState');
  setStatus(status, 'mail.wait', 'wait');
  var reply = await placement('finish', {
    attempt: ST.attempt,
    app: ST.app,
    answers: ST.submitted,
    retry: ST.retry
  });
  ST.submitting = false;
  $('#exitExam').disabled = false;

  if (!reply.result) {
    var expired = reply.error === 'attemptExpired' || reply.error === 'conflict' || reply.error === 'invalid';
    if (ST.result) {
      setStatus(status, expired ? 'mail.expired' : 'mail.bad', 'bad');
      $('#retryMail').hidden = expired;
      updateDone();
    } else {
      ST.pending = !expired;
      setStatus(status, expired ? 'sb.expired' : reply.error === 'rate' ? 'net.rate' : 'sb.bad', 'bad');
      $('#restartTest').hidden = !expired;
      $('#retrySubmit').hidden = expired;
    }
    return;
  }

  ST.pending = false;
  ST.result = reply.result;
  ST.emailSent = reply.emailSent;
  ST.retry = reply.retry || '';
  if (ST.emailSent) ST.submitted = null;
  setStatus($('#mailState2'), ST.emailSent ? 'mail.okR' : 'mail.bad', ST.emailSent ? 'ok' : 'bad');
  $('#retryMail').hidden = ST.emailSent;
  $('#rsNext').hidden = !ST.emailSent;
  showResult();
}

function fillResult() {
  var r = ST.result, a = ST.app;
  if (!r) return;
  $('#rsName').textContent = a.firstName + ' ' + a.lastName;
  $('#rsLevel').textContent = r.level;
  $('#rsLvName').textContent = t('lvn.' + r.level);
  $('#rsLvDesc').textContent = t('lvd.' + r.level);
  $('#rsScore').textContent = r.correct + '/' + r.total;
  $('#rsPct').textContent = Math.round(r.correct / r.total * 100) + '%';
  $('#rsTime').textContent = mmss(r.elapsed);
  $('#rsRef').textContent = t('rs.ref', { ref: ST.ref });
  var h = '';
  LEVELS.forEach(function (l) {
    var p = r.per[l[0]], pc = Math.round(p.c / p.n * 100);
    h += '<div class="bar' + (p.c / p.n >= .6 ? ' pass' : '') + '"><span dir="ltr">' + l[0] +
      '</span><i><b data-w="' + pc + '"></b></i><span>' + p.c + '/' + p.n + '</span></div>';
  });
  $('#rsBars').innerHTML = h;
  $$('#rsBars b').forEach(function (bar) {
    bar.style.setProperty('--w', bar.dataset.w + '%');
    requestAnimationFrame(function () { bar.style.width = bar.dataset.w + '%'; });
  });
}

function showResult() {
  screen('scrRes');
  $('#timer').hidden = true;
  $('#examProg').style.width = '100%';
  setStep(3);
  fillResult();
  updateDone();
}

function updateDone() {
  if (!ST.result || !ST.app) return;
  var r = ST.result;
  $('#doneText').textContent = t('dn.text', { name: ST.app.firstName, lv: r.level, lvn: t('lvn.' + r.level) });
  $('#doneFacts').innerHTML = '<span><svg class="ico"><use href="#i-trophy"/></svg>' +
    esc(t('dn.f1', { lv: r.level })) + '</span><span><svg class="ico"><use href="#i-clip"/></svg>' +
    esc(t('dn.f2', { s: fmt(r.correct), t: fmt(r.total) })) + '</span>';
  var key = $('#mailState2').dataset.mk;
  setStatus($('#doneMail'), key, ST.emailSent ? 'ok' : 'bad');
}
function closeResult() {
  closeExam();
  updateDone();
  showPane('paneDone');
  setStep(ST.emailSent ? 4 : 3);
  $('#viewResult').focus({ preventScroll: true });
  $('.formcard').scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'start' });
}

$('#retrySubmit').addEventListener('click', submitTest);
$('#retryMail').addEventListener('click', submitTest);
$('#restartTest').addEventListener('click', function () {
  ST.submitted = null;
  openExam();
});
$('#closeRes').addEventListener('click', closeResult);
$('#viewResult').addEventListener('click', openExam);
$('#printBtn').addEventListener('click', function () { window.print(); });

applyLang(window.__startLang || 'en', false);
})();
